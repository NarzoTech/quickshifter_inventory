<?php

return [
    'name' => 'Tax',
];
