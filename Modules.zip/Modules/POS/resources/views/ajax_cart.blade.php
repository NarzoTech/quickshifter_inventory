<table class="table table-bordered product-table">
    <thead class="text-center" style="background: #00a65a">
        <tr style="height: 25px; color: #fff;">
            <th style="padding:4px 0px; margin:0px; width: 30%;">Name</th>
            <th style="padding:4px 0px; margin:0px; width: 5%;">Source</th>
            <th style="padding:4px 0px; margin:0px; width: 5%;">Qty</th>
            <th style="padding:4px 0px; margin:0px; width: 7%;">Price</th>
            <th style="padding:4px 0px; margin:0px; width: 10%;">Total</th>
            <th style="padding:4px 0px; margin:0px; width: 5%;">
                <i class="fa fa-trash"></i>
            </th>
        </tr>
    </thead>
    <tbody>
        @php
            $cumalitive_sub_total = $cumalitive_sub_total ?? 0;
        @endphp
        @foreach ($cart_contents as $cart_index => $cart_content)
            <tr data-rowid="{{ $cart_content['rowid'] }}">
                <td>
                    <p>{{ $cart_content['name'] }}</p>
                    @if (isset($cart_content['variant']))
                        <span>
                            {{ $cart_content['variant']['attribute'] }}
                        </span>
                    @endif
                </td>
                <td>
                    @if ($cart_content['type'] == 'product')
                        <select name="source" id="source">
                            <option value="1" @if ($cart_content['source'] == '1') selected @endif>From Stock</option>
                            <option value="2" @if ($cart_content['source'] == '2') selected @endif>From Out Side
                            </option>
                        </select>
                    @endif
                </td>
                <td data-rowid="{{ $cart_content['rowid'] }}" class="px-3">
                    <input min="1" type="number" value="{{ $cart_content['qty'] }}"
                        class="pos_input_qty form-control">
                </td>

                <td class="price">
                    <span>
                        {{ currency($cart_content['price']) }}
                    </span>
                    <input type="text" value="{{ $cart_content['price'] }}" name="table_price[]" style="width:100px"
                        data-rowid="{{ $cart_content['rowid'] }}" class="d-none">
                </td>
                @php
                    $sub_total = $cart_content['sub_total'];
                    $cumalitive_sub_total += $sub_total;
                @endphp

                <td class="row_total">{{ currency($sub_total) }}</td>

                <td class="d-flex justify-content-center align-items-center">
                    <a href="javascript:;" onclick="removeCartItem('{{ $cart_content['rowid'] }}')"
                        class="d-block p-2 "><i class="fa fa-trash text-danger" aria-hidden="true"></i></a>

                    <a href="javascript:;" class="edit-btn {{ $cart_content['source'] == '2' ? '' : 'd-none' }}"
                        data-purchase="{{ $cart_content['purchase_price'] }}"
                        data-selling="{{ $cart_content['selling_price'] }}">
                        <i class="fas fa-edit"></i>
                    </a>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>
