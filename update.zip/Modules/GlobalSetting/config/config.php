<?php

return [
    'name' => 'GlobalSetting',
];
