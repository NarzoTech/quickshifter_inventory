<?php

return [
    'name' => 'Expense',
];
