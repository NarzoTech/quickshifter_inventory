<?php

return [
    'name' => 'Message',
];
