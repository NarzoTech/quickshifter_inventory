<?php

return [
    'name' => 'Attendance',
];
