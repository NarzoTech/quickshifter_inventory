<?php

return [
    'name' => 'POS',
];
