<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\MenuBuilder\\app\\Providers\\MenuBuilderServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\MenuBuilder\\app\\Providers\\MenuBuilderServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);