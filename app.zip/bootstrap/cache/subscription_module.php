<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Subscription\\app\\Providers\\SubscriptionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Subscription\\app\\Providers\\SubscriptionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);