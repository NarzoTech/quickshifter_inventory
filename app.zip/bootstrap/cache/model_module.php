<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Model\\app\\Providers\\ModelServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Model\\app\\Providers\\ModelServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);