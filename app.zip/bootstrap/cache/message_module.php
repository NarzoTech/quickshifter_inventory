<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Message\\app\\Providers\\MessageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Message\\app\\Providers\\MessageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);