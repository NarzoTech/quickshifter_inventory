<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\OurTeam\\app\\Providers\\OurTeamServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\OurTeam\\app\\Providers\\OurTeamServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);