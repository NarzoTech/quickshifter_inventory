<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Service\\app\\Providers\\ServiceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Service\\app\\Providers\\ServiceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);