<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Sales\\app\\Providers\\SalesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Sales\\app\\Providers\\SalesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);