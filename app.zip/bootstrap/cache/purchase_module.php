<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Purchase\\app\\Providers\\PurchaseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Purchase\\app\\Providers\\PurchaseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);