<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Accounts\\app\\Providers\\AccountsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Accounts\\app\\Providers\\AccountsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);