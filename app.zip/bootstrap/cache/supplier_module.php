<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Supplier\\app\\Providers\\SupplierServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Supplier\\app\\Providers\\SupplierServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);