<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Expense\\app\\Providers\\ExpenseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Expense\\app\\Providers\\ExpenseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);