<?php

return [
    'name' => 'Report',
];
