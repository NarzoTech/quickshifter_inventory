<?php

namespace Modules\Purchase\app\Http\Controllers;

use App\Enums\RedirectType;
use App\Http\Controllers\Controller;
use App\Traits\RedirectHelperTrait;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Modules\Accounts\app\Models\Account;
use Modules\Purchase\app\Services\PurchaseService;

class PurchaseReturnController extends Controller
{
    use RedirectHelperTrait;
    public function __construct(private PurchaseService $purchaseService)
    {
        $this->middleware('auth:admin');
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $returns = $this->purchaseService->allReturn()->paginate(20);
        return view('purchase::return.index', compact('returns'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create($id)
    {
        $purchase = $this->purchaseService->getPurchase($id);
        $returnTypes = $this->purchaseService->getReturnTypes();
        return view('purchase::return.create', compact('purchase', 'returnTypes'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, $id): RedirectResponse
    {
        $request->validate([
            'supplier_id' => 'required',
            'return_date' => 'required',
        ]);

        DB::beginTransaction();
        try {
            $this->purchaseService->storeReturn($request, $id);

            DB::commit();
            return $this->redirectWithMessage(RedirectType::CREATE->value, 'admin.purchase.return.index', [], ['messege' => 'Purchase Return Created Successfully', 'alert-type' => 'success']);
        } catch (Exception $ex) {

            DB::rollBack();
            Log::error($ex->getMessage());
            return $this->redirectWithMessage(RedirectType::ERROR->value, 'admin.purchase.return.index', [], ['messege' => 'Something Went Wrong', 'alert-type' => 'error']);
        }
    }

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('purchase::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $return = $this->purchaseService->getPurchaseReturn($id);
        $purchase = $return->purchase;
        $returnTypes = $this->purchaseService->getReturnTypes();
        $accounts = $this->purchaseService->getAccounts();
        $payment = $return->payment;
        return view('purchase::return.edit', compact('return', 'purchase', 'returnTypes', 'accounts', 'payment'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id): RedirectResponse
    {
        dd($request->all());
        $request->validate([
            'supplier_id' => 'required',
            'return_date' => 'required',
        ]);

        DB::beginTransaction();
        try {
            $this->purchaseService->updateReturn($request, $id);

            DB::commit();
            return $this->redirectWithMessage(RedirectType::CREATE->value, 'admin.purchase.return.index', [], ['messege' => 'Purchase Return Created Successfully', 'alert-type' => 'success']);
        } catch (Exception $ex) {

            DB::rollBack();
            Log::error($ex->getMessage());
            return $this->redirectWithMessage(RedirectType::ERROR->value, 'admin.purchase.return.index', [], ['messege' => 'Something Went Wrong', 'alert-type' => 'error']);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        // delete ledger

        $this->purchaseService->deleteReturn($id);


        return $this->redirectWithMessage(RedirectType::DELETE->value, 'admin.purchase.return.index', [], ['messege' => 'Purchase Return Deleted Successfully', 'alert-type' => 'success']);
    }
}
